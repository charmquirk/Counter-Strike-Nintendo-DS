New Fontendo 23DSi Lite XL is a font that replicates the one used for the Nintendo DS/3DS families' logos.

2015 - MaxiGamer - maxigamer.deviantart.com
Made with FontForge.